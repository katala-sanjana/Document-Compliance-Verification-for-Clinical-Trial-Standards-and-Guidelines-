import { useCallback, useRef, useState } from "react";
import { FileText, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface Props {
  onFile: (file: File) => void;
  isUploading: boolean;
  progress: number;
}

export function FileUpload({ onFile, isUploading, progress }: Props) {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files || !files[0]) return;
    const f = files[0];
    if (f.type !== "application/pdf" && !f.name.toLowerCase().endsWith(".pdf")) {
      alert("Only PDF files are accepted.");
      return;
    }
    setFile(f);
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
        onClick={() => !file && inputRef.current?.click()}
        className={`glass relative rounded-3xl p-10 sm:p-14 text-center cursor-pointer transition-all duration-300 ${
          dragging ? "scale-[1.02] ring-2 ring-primary" : "hover:scale-[1.01]"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />

        {!file ? (
          <div className="flex flex-col items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary to-teal flex items-center justify-center text-primary-foreground shadow-lg animate-float">
              <Upload className="h-7 w-7" />
            </div>
            <div>
              <p className="text-lg font-semibold">Drop your FDA document here</p>
              <p className="text-sm text-muted-foreground mt-1">
                or click to browse — PDF only, up to 50MB
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3 glass rounded-2xl px-4 py-3 w-full max-w-md">
              <FileText className="h-5 w-5 text-primary shrink-0" />
              <div className="flex-1 text-left min-w-0">
                <p className="font-medium truncate">{file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
              {!isUploading && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  className="h-8 w-8 rounded-full"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            {isUploading ? (
              <div className="w-full max-w-md space-y-2">
                <Progress value={progress} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {progress < 100 ? `Uploading… ${progress}%` : "Analyzing with AI…"}
                </p>
              </div>
            ) : (
              <Button
                size="lg"
                onClick={(e) => { e.stopPropagation(); onFile(file); }}
                className="rounded-full px-8 bg-gradient-to-r from-primary to-teal hover:opacity-90"
              >
                Analyze Compliance
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
