import { Sparkles } from "lucide-react";

export function AILoader({ stage }: { stage?: string }) {
  return (
    <div className="glass rounded-3xl p-10 flex flex-col items-center gap-6 animate-fade-in">
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary to-teal blur-2xl opacity-50 animate-pulse" />
        <div className="relative h-20 w-20 rounded-full bg-gradient-to-br from-primary to-teal flex items-center justify-center text-primary-foreground shadow-xl">
          <Sparkles className="h-9 w-9 animate-pulse" />
        </div>
      </div>
      <div className="text-center space-y-2">
        <p className="text-lg font-semibold">AI is reviewing your document</p>
        <p className="text-sm text-muted-foreground max-w-sm">
          {stage ?? "Scanning for FDA compliance issues, risks, and regulatory gaps…"}
        </p>
      </div>
      <div className="flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="h-2 w-2 rounded-full bg-primary"
            style={{ animation: `float 1.2s ease-in-out ${i * 0.15}s infinite` }}
          />
        ))}
      </div>
    </div>
  );
}
