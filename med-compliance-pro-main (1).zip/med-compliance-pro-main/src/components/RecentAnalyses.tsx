import { Clock, FileText, Trash2 } from "lucide-react";
import type { AnalysisRecord } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Props {
  items: AnalysisRecord[];
  onSelect: (rec: AnalysisRecord) => void;
  onDelete: (id: string) => void;
}

export function RecentAnalyses({ items, onSelect, onDelete }: Props) {
  if (!items.length) return null;
  return (
    <Card className="glass p-6 rounded-3xl border-glass-border">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Clock className="h-5 w-5 text-primary" />
        Recent Analyses
      </h3>
      <div className="grid gap-2">
        {items.map((r) => (
          <div
            key={r.id}
            className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted/60 cursor-pointer transition-colors group"
            onClick={() => onSelect(r)}
          >
            <FileText className="h-4 w-4 text-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{r.fileName}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(r.createdAt).toLocaleString()}
              </p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8 opacity-0 group-hover:opacity-100"
              onClick={(e) => { e.stopPropagation(); onDelete(r.id); }}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
}
