import { AlertTriangle, CheckCircle2, Info, ShieldAlert } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type Severity = "high" | "medium" | "low" | "info";

function severityOf(text: string): Severity {
  const t = text.toLowerCase();
  if (/(high|critical|severe|major|fail|violation|non[- ]?compliant)/.test(t)) return "high";
  if (/(medium|moderate|warning|caution)/.test(t)) return "medium";
  if (/(low|minor|info)/.test(t)) return "low";
  return "info";
}

const sevStyles: Record<Severity, { bg: string; text: string; icon: typeof AlertTriangle }> = {
  high: { bg: "bg-danger/10 border-danger/30", text: "text-danger", icon: ShieldAlert },
  medium: { bg: "bg-warning/10 border-warning/30", text: "text-warning", icon: AlertTriangle },
  low: { bg: "bg-success/10 border-success/30", text: "text-success", icon: CheckCircle2 },
  info: { bg: "bg-primary/10 border-primary/30", text: "text-primary", icon: Info },
};

function isRiskLike(key: string): boolean {
  return /(risk|alert|issue|violation|warning|finding|concern|flag)/i.test(key);
}
function isSummaryLike(key: string): boolean {
  return /(summary|overview|score|status|compliance|result|verdict|recommendation)/i.test(key);
}

function prettyKey(k: string) {
  return k.replace(/[_-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function extractText(v: unknown): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return v.map(extractText).join(", ");
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    return (o.message ?? o.description ?? o.title ?? o.text ?? JSON.stringify(o)) as string;
  }
  return String(v);
}

function RiskItem({ item, fallbackSeverity }: { item: unknown; fallbackSeverity?: Severity }) {
  const obj = typeof item === "object" && item !== null ? (item as Record<string, unknown>) : null;
  const title = obj
    ? String(obj.title ?? obj.name ?? obj.issue ?? obj.category ?? "Finding")
    : "Finding";
  const message = obj
    ? String(obj.message ?? obj.description ?? obj.detail ?? obj.text ?? extractText(item))
    : extractText(item);
  const sevRaw = obj ? String(obj.severity ?? obj.level ?? obj.risk ?? "") : "";
  const severity: Severity = sevRaw ? severityOf(sevRaw) : fallbackSeverity ?? severityOf(message + " " + title);
  const s = sevStyles[severity];
  const Icon = s.icon;

  return (
    <div className={`flex gap-3 rounded-2xl border p-4 ${s.bg}`}>
      <Icon className={`h-5 w-5 shrink-0 mt-0.5 ${s.text}`} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-medium">{title}</p>
          <Badge variant="outline" className={`${s.text} border-current text-xs capitalize`}>
            {sevRaw || severity}
          </Badge>
        </div>
        {message && message !== title && (
          <p className="text-sm text-muted-foreground mt-1 break-words">{message}</p>
        )}
        {obj && (obj.recommendation || obj.suggestion || obj.fix) ? (
          <p className="text-sm mt-2">
            <span className="font-medium">Recommendation: </span>
            {String(obj.recommendation ?? obj.suggestion ?? obj.fix)}
          </p>
        ) : null}
      </div>
    </div>
  );
}

export function RiskAlerts({ items }: { items: unknown[] }) {
  if (!items.length) return null;
  return (
    <Card className="glass p-6 rounded-3xl border-glass-border">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <ShieldAlert className="h-5 w-5 text-danger" />
        Risk Alerts ({items.length})
      </h3>
      <div className="space-y-3">
        {items.map((it, i) => <RiskItem key={i} item={it} />)}
      </div>
    </Card>
  );
}

export function SummaryCards({ entries }: { entries: [string, unknown][] }) {
  if (!entries.length) return null;
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {entries.map(([k, v]) => {
        const text = extractText(v);
        const isScore = typeof v === "number" || /^\d+(\.\d+)?%?$/.test(text);
        return (
          <Card key={k} className="glass p-5 rounded-2xl border-glass-border hover:scale-[1.02] transition-transform">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
              {prettyKey(k)}
            </p>
            {isScore ? (
              <p className="text-3xl font-bold text-gradient mt-2">{text}</p>
            ) : (
              <p className="text-sm mt-2 line-clamp-4">{text}</p>
            )}
          </Card>
        );
      })}
    </div>
  );
}

function JsonNode({ value, depth = 0 }: { value: unknown; depth?: number }) {
  if (value == null) return <span className="text-muted-foreground italic">none</span>;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return <span className="break-words">{String(value)}</span>;
  }
  if (Array.isArray(value)) {
    if (!value.length) return <span className="text-muted-foreground italic">empty</span>;
    return (
      <ul className="space-y-2 list-disc list-inside ml-2">
        {value.map((v, i) => (
          <li key={i}><JsonNode value={v} depth={depth + 1} /></li>
        ))}
      </ul>
    );
  }
  return (
    <div className="space-y-3">
      {Object.entries(value as Record<string, unknown>).map(([k, v]) => (
        <div key={k} className={depth > 0 ? "pl-3 border-l border-border" : ""}>
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium mb-1">
            {prettyKey(k)}
          </p>
          <div className="text-sm"><JsonNode value={v} depth={depth + 1} /></div>
        </div>
      ))}
    </div>
  );
}

export function DynamicSection({ title, value }: { title: string; value: unknown }) {
  return (
    <Card className="glass p-6 rounded-3xl border-glass-border">
      <h3 className="text-lg font-semibold mb-4">{prettyKey(title)}</h3>
      <JsonNode value={value} />
    </Card>
  );
}

export interface ParsedResult {
  summary: [string, unknown][];
  risks: unknown[];
  other: [string, unknown][];
}

export function parseAnalysis(data: unknown): ParsedResult {
  const summary: [string, unknown][] = [];
  const risks: unknown[] = [];
  const other: [string, unknown][] = [];

  if (data == null || typeof data !== "object") {
    return { summary: [], risks: [], other: [["Result", data]] };
  }

  for (const [k, v] of Object.entries(data as Record<string, unknown>)) {
    if (isRiskLike(k) && Array.isArray(v)) {
      risks.push(...v);
    } else if (isRiskLike(k) && v && typeof v === "object") {
      risks.push(v);
    } else if (isSummaryLike(k) && (typeof v === "string" || typeof v === "number" || typeof v === "boolean")) {
      summary.push([k, v]);
    } else if (
      typeof v === "string" || typeof v === "number" || typeof v === "boolean"
    ) {
      summary.push([k, v]);
    } else {
      other.push([k, v]);
    }
  }
  return { summary, risks, other };
}
