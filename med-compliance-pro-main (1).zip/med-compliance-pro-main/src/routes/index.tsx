import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, RotateCcw, ShieldCheck, Sparkles, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { FileUpload } from "@/components/FileUpload";
import { AILoader } from "@/components/AILoader";
import {
  DynamicSection,
  RiskAlerts,
  SummaryCards,
  parseAnalysis,
} from "@/components/Dashboard";
import { RecentAnalyses } from "@/components/RecentAnalyses";
import { analyzePdf, type AnalysisRecord } from "@/lib/api";
import { deleteAnalysis, getRecent, saveAnalysis } from "@/lib/storage";
import { toast, Toaster } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ComplyAI — AI-Powered FDA Compliance Assistant" },
      {
        name: "description",
        content:
          "Upload FDA documents and get instant AI-driven compliance analysis, risk alerts, and exportable reports.",
      },
      { property: "og:title", content: "ComplyAI — FDA Compliance Assistant" },
      {
        property: "og:description",
        content: "Instant AI compliance review for FDA documents.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const [result, setResult] = useState<unknown>(null);
  const [fileName, setFileName] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<AnalysisRecord[]>(() =>
    typeof window !== "undefined" ? getRecent() : [],
  );

  async function handleFile(file: File) {
    setLoading(true);
    setProgress(0);
    setError(null);
    setResult(null);
    try {
      const data = await analyzePdf(file, setProgress);
      setResult(data);
      setFileName(file.name);
      const rec: AnalysisRecord = {
        id: crypto.randomUUID(),
        fileName: file.name,
        createdAt: Date.now(),
        data,
      };
      saveAnalysis(rec);
      setRecent(getRecent());
      toast.success("Analysis complete");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  function exportReport() {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${fileName.replace(/\.pdf$/i, "") || "report"}-compliance.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function reset() {
    setResult(null);
    setError(null);
    setFileName("");
    setProgress(0);
  }

  const parsed = result ? parseAnalysis(result) : null;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 gradient-mesh pointer-events-none -z-10" />
      <Toaster position="top-right" richColors />

      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-glass-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary to-teal flex items-center justify-center text-primary-foreground shadow-md">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold leading-none">ComplyAI</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
                FDA Compliance
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {result != null && (
              <>
                <Button variant="ghost" size="sm" onClick={reset} className="rounded-full">
                  <RotateCcw className="h-4 w-4 mr-1" /> New
                </Button>
                <Button size="sm" onClick={exportReport} className="rounded-full bg-gradient-to-r from-primary to-teal">
                  <Download className="h-4 w-4 mr-1" /> Export
                </Button>
              </>
            )}
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
        {!result && !loading && (
          <section className="text-center max-w-3xl mx-auto mb-10 sm:mb-14 animate-fade-in">
            <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-xs mb-6 border-glass-border">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              <span>Powered by AI · Built for regulatory teams</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight">
              FDA compliance,{" "}
              <span className="text-gradient">decoded in seconds</span>
            </h1>
            <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-xl mx-auto">
              Upload any FDA-related document and get an instant AI compliance review —
              risks, findings, and recommendations in one clean dashboard.
            </p>
          </section>
        )}

        {loading && (
          <div className="max-w-2xl mx-auto">
            <AILoader stage={progress < 100 ? `Uploading document… ${progress}%` : undefined} />
          </div>
        )}

        {!result && !loading && (
          <>
            <FileUpload onFile={handleFile} isUploading={loading} progress={progress} />

            {error && (
              <div className="max-w-2xl mx-auto mt-6 rounded-2xl border border-danger/40 bg-danger/10 p-4 text-sm text-danger">
                {error}
              </div>
            )}

            <div className="grid gap-4 sm:grid-cols-3 max-w-4xl mx-auto mt-14">
              {[
                { icon: Zap, title: "Instant analysis", desc: "Results in seconds, not days." },
                { icon: ShieldCheck, title: "Risk-first", desc: "Issues ranked by severity." },
                { icon: Sparkles, title: "AI-curated", desc: "Clear, actionable recommendations." },
              ].map((f) => (
                <div key={f.title} className="glass rounded-2xl p-5 border-glass-border">
                  <f.icon className="h-5 w-5 text-primary mb-2" />
                  <p className="font-medium">{f.title}</p>
                  <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
                </div>
              ))}
            </div>

            {recent.length > 0 && (
              <div className="max-w-3xl mx-auto mt-10">
                <RecentAnalyses
                  items={recent}
                  onSelect={(r) => {
                    setResult(r.data);
                    setFileName(r.fileName);
                  }}
                  onDelete={(id) => {
                    deleteAnalysis(id);
                    setRecent(getRecent());
                  }}
                />
              </div>
            )}
          </>
        )}

        {result != null && parsed && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h2 className="text-2xl font-bold">Compliance Dashboard</h2>
                <p className="text-sm text-muted-foreground">{fileName}</p>
              </div>
            </div>

            {parsed.summary.length > 0 && <SummaryCards entries={parsed.summary} />}
            {parsed.risks.length > 0 && <RiskAlerts items={parsed.risks} />}
            {parsed.other.map(([k, v]) => (
              <DynamicSection key={k} title={k} value={v} />
            ))}

            {parsed.summary.length === 0 && parsed.risks.length === 0 && parsed.other.length === 0 && (
              <div className="glass rounded-3xl p-8 border-glass-border">
                <pre className="text-xs overflow-auto">{JSON.stringify(result, null, 2)}</pre>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="border-t border-glass-border mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 text-xs text-muted-foreground flex justify-between">
          <span>© {new Date().getFullYear()} ComplyAI</span>
          <span>For informational purposes only — not legal advice.</span>
        </div>
      </footer>
    </div>
  );
}
