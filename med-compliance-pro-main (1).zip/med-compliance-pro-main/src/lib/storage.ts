import type { AnalysisRecord } from "./api";

const KEY = "fda_recent_analyses";
const MAX = 10;

export function getRecent(): AnalysisRecord[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "[]");
  } catch {
    return [];
  }
}

export function saveAnalysis(rec: AnalysisRecord) {
  const list = [rec, ...getRecent().filter((r) => r.id !== rec.id)].slice(0, MAX);
  localStorage.setItem(KEY, JSON.stringify(list));
}

export function deleteAnalysis(id: string) {
  localStorage.setItem(KEY, JSON.stringify(getRecent().filter((r) => r.id !== id)));
}

export function clearAnalyses() {
  localStorage.removeItem(KEY);
}
