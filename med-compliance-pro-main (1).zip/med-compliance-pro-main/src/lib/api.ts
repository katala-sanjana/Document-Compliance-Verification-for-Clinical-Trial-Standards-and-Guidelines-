export interface AnalysisRecord {
  id: string;
  fileName: string;
  createdAt: number;
  data: unknown;
}

const API_URL = "https://renegade-heat-gliding.ngrok-free.dev/analyze";

export async function analyzePdf(
  file: File,
  onProgress?: (pct: number) => void,
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", API_URL, true);
    xhr.setRequestHeader("ngrok-skip-browser-warning", "true");

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          resolve(xhr.responseText);
        }
      } else {
        reject(new Error(`Server responded with ${xhr.status}: ${xhr.statusText}`));
      }
    };

    xhr.onerror = () => reject(new Error("Network error. Please check your connection."));
    xhr.ontimeout = () => reject(new Error("Request timed out."));

    const fd = new FormData();
    fd.append("file", file);
    xhr.send(fd);
  });
}
